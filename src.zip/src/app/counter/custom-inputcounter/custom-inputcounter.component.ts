import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { customInput } from '../state/counter.actions';
import { CounterState } from '../state/counter.state';
import { webSocket } from 'rxjs/webSocket';

@Component({
  selector: 'app-custom-inputcounter',
  templateUrl: './custom-inputcounter.component.html',
  styleUrls: ['./custom-inputcounter.component.scss']
})
export class CustomInputcounterComponent implements OnInit {
  value:number = 0;

  title = "client"; 
  subject = webSocket('ws://localhost:8082');

  constructor(private store : Store<{ counter : CounterState }>) {

    this.subject.subscribe(
      (msg:any) => {
        console.log('message received: ' + msg);
        if(typeof msg == "number"){
          this.store.dispatch(customInput({ value : +msg}))
        }
    
      },
      // Called whenever there is a message from the server
      (err) => console.log(err),
      // Called if WebSocket API signals some kind of error
      () => console.log('complete')
      // Called when connection is closed (for whatever reason)
   );
   }

  ngOnInit(): void {
  }

  submitvalue(): void{

    this.subject.subscribe();
    this.subject.next(this.value);
    //this.subject.complete();

    //this.store.dispatch(customInput({ value : +this.value}))
  }

}
