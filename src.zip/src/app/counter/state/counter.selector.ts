import { createFeatureSelector, createSelector } from "@ngrx/store";
import { CounterState, PatientState } from "./counter.state";

const getCounterState = createFeatureSelector<CounterState>('counter');

export const getCounter = createSelector(getCounterState, (state) => {
    return state.counter;
})

const getPatientState = createFeatureSelector<PatientState>('patient');

export const getPatients = createSelector(getPatientState, (state) => {
    return state.patient;
})