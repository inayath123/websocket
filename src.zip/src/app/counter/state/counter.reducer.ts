import { createReducer, on } from "@ngrx/store";
import { decreement, increement, reset, customInput, getPatient } from "./counter.actions";
import { initialState, patientStateInitialize } from "./counter.state";

const _counterReducer = createReducer(
    initialState, 
    on(increement, (state) => {
        return {
            ...state,
            counter: state.counter + 1,
        };
}),on(decreement, (state) => {
    return {
        ...state,
        counter: state.counter - 1,
    };
}),on(reset, (state) => {
    return {
        ...state,
        counter: 0,
    };
}),on(customInput, (state, action) => {
    return {
        ...state,
        counter: state.counter + action.value,
    };
})
);

export function counterReducer(state:any,action:any){
    return _counterReducer(state,action);
}


const _patientReducer = createReducer(
    patientStateInitialize, 
    on(getPatient, (state, action) => {
        console.log("action patient",action)

        

        return {
            ...state,
            patient: state.patient.concat(action.patient),
        };
})
);

export function patientReducer(state:any,action:any){
    return _patientReducer(state,action);
}