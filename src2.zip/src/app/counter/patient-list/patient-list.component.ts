import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { webSocket } from 'rxjs/webSocket';
import { getPatient } from '../state/counter.actions';
import { getPatients } from '../state/counter.selector';
import { PatientState } from '../state/counter.state';

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.scss']
})
export class PatientListComponent implements OnInit {
  title = "client"; 
  subject = webSocket('ws://localhost:8082');
  
  patient$: Observable<any> | undefined;
  constructor(private store : Store<{ patient : PatientState }>) {
    this.subject.subscribe(
      (msg:any) => {
        console.log('message received: ' + msg);
        this.store.dispatch(getPatient({ patient : msg}));
        this.patient$ = this.store.select(getPatients);
      }, 
      (err) => console.log(err), 
      () => console.log('complete') 
   );
   }


  ngOnInit(): void {
    this.patient$ = this.store.select(getPatients);
  }

  getPatientList(){
    this.subject.subscribe();
    this.subject.next("SEND_PATIENT_LIST");
   // this.store.dispatch(getPatient({ patient : this.patient$}));
  }
}


