import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomInputcounterComponent } from './custom-inputcounter.component';

describe('CustomInputcounterComponent', () => {
  let component: CustomInputcounterComponent;
  let fixture: ComponentFixture<CustomInputcounterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomInputcounterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomInputcounterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
