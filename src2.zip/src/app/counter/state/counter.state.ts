export interface CounterState {
    counter:number;
}

export const initialState:CounterState = {
    counter:0,
};

export interface PatientState {
   patient:any
}

export const patientStateInitialize:PatientState = {
    patient : [{
        firstName: "Inayath",
        lastName: "Nargundkar",
        hospital: "Apollo",
        ward: "ICU",
        room: "ICU2"
    }]

};