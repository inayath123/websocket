import { createAction, props  } from "@ngrx/store";

export const increement = createAction('increement');
export const decreement = createAction('decreement');
export const reset = createAction('reset');

export const customInput = createAction('customincreement',props<{ value : number}>());

export const getPatient = createAction('getPatient',props<{ patient : any }>());